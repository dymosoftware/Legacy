function PrintLabel()
{
	try
	{
		// this is the proper way to create the DYMO XPCom objects
		DymoAddIn = new nsDymoAddIn();
		DymoLabels = new nsDymoLabels();


        	if (DymoLabels.SetAddress(1, 'Pablo Martini1\nSAMPLE Corporation\n333 W. Fantasy World\nSantaland, NP 99999-9999'))
		{
		        DymoAddIn.Print(1, false);
	        }
        	else
		        alert('Current label does not contain an address object');
	}
	catch (err)
	{
		alert(err);
		return;
	}
}
