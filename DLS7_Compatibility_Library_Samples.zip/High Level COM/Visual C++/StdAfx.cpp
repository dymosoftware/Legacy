// stdafx.cpp : source file that includes just the standard includes
//	hlOLEDemo.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

//#define DEFINE_GUIDSTRUCT(g, n) struct __declspec(uuid(g)) n
//#define DEFINE_GUIDNAMED(n) __uuidof(struct n)

//#define STATIC_GUID_NULL \
//    0x00000000L, 0x0000, 0x0000, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

//DEFINE_GUIDSTRUCT("00000000-0000-0000-0000-000000000000", GUID_NULL);
//#define GUID_NULL DEFINE_GUIDNAMED(GUID_NULL)

//#define SAS_COMPILATION

#include "stdafx.h"

