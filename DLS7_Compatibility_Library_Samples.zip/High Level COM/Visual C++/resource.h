//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hlOLEDemo.rc
//
#define IDC_PRINT                       101
#define IDD_DDEDEMO_DIALOG              102
#define IDC_GETFIELDS                   102
#define IDD_HLOLEDEMO_DIALOG            102
#define IDC_SHOWWINDOW                  103
#define IDC_HIDEDLS                     103
#define IDC_FIELDS                      104
#define IDC_EDIT                        105
#define IDC_FIELDTEXT                   105
#define IDC_SETTEXT                     106
#define IDC_OPENFILE                    107
#define IDC_TEMPLATE                    108
#define IDC_SAVEFILE                    108
#define IDC_GROUPBOX1                   109
#define IDC_GROUPBOX2                   110
#define IDC_LASTERROR                   111
#define IDC_SYSTRAY                     111
#define IDC_ADDRESSTEXT                 112
#define IDC_SETADDRESS                  113
#define IDR_MAINFRAME                   128
#define IDC_VARONLY                     1001
#define IDC_RBNONE                      1002
#define IDC_RBABOVE                     1003
#define IDC_RBBELOW                     1004
#define IDC_NADDRESS                    1005
#define IDC_SPIN                        1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
