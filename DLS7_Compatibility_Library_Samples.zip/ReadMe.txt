DYMO Label SDK Samples Read Me
Revision: 1
Date: 12/03/2009

Overview
The samples demonstrate how to use both the High Level and Low Level COM interfaces documented in the DLS 7 SDK Manual. These samples can run as is without rebuilding on client systems with DLS 7 or DLS 8 installed. This demonstrates the "binary compatible" implementation of the DLS 7 Compatibility Library.

32 Bit Library
Because the DLS 7 Compatibility Library is a 32-bit library, the samples are compiled to target x86 platforms and will run as Wow6432 applications under 64-bit operating systems.

* note: Use the 32-bit version of Internet Explorer (IE) to run the IE samples on 64-bit operating systems with both 32-bit and 64-bit versions of IE installed. The ActiveX controls used in the sample scripts are 32-bit only, so the controls will not load in the 64-bit version of IE.

FireFox Sample
Make sure to install the DYMO SDK FireFox extension before running the FireFox sample. See install.htm in the sample folder.
